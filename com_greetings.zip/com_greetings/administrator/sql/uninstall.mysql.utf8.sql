DROP TABLE IF EXISTS `#__greetings`;
