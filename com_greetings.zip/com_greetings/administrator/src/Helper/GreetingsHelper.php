<?php
	
/**
 * @version    CVS: 1.0.0
 * @package    Com_Greetings
 * @author     Ankit Jagetia <akjagetia@gmail.com>
 * @copyright  2024 Samy Web Technologies
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace Samywebtechnologies\Component\Greetings\Administrator\Helper;
		
// No direct access
defined('_JEXEC') or die;

/**
 * Greetings helper.
 *
 * @since  1.0.0
 */
class GreetingsHelper
{
	
}

